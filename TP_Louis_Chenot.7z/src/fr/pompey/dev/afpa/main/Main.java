package fr.pompey.dev.afpa.main;
import fr.pompey.dev.afpa.utilitaires.*;

import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Exercice_1 exo1 = new Exercice_1();
        // exo1.exercice1(sc);

        Exercice_2 exo2 = new Exercice_2();
        // exo2.exercice2(sc);

        Exercice_3 exo3 = new Exercice_3();
        // exo3.exercice3(sc);

        Exercice_4 exo4 = new Exercice_4();
        // exo4.exercice4(sc);

        Exercice_5 exo5 = new Exercice_5();
        // exo5.exercice5(sc);

        Exercice_6 exo6 = new Exercice_6();
        // exo6.exercice6(sc);

        Exercice_7 exo7 = new Exercice_7();
        // exo7.exercice7(sc);
    }
}